#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ArduinoJson.h>
#include <math.h>

// 1. Configuración de tu Red WiFi (Punto de acceso del móvil)
//#define WIFI_SSID "gordos"
#define WIFI_SSID "B15-ALUMNOS"
#define WIFI_PASSWORD "holacaracola"

// 2. Endpoint de Firebase
const String URL_ENDPOINT = "https://jbc-app-daw-default-rtdb.europe-west1.firebasedatabase.app/datos.json";

// 3. Variables de Control de Tiempo y Comando
unsigned long tiempoAnterior = 0;
unsigned long intervalo = 30000; // Intervalo inicial: 30 segundos
bool envioActivo = true;       

// 4. Variables de simulación en Círculo (Centro en Ciudad Real)
const double CENTRO_LAT = 38.98626;
const double CENTRO_LON = -3.92742;
const double RADIO_GIRO = 0.005; 
double angulo = 0.0;              

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("\n--- Iniciando Telemetría jbc coche electrico ---");

  // Conexión WiFi
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("Conectando a WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\n¡Conectado con éxito!");
  Serial.print("IP local: ");
  Serial.println(WiFi.localIP());

  // Espera de estabilización para la red del móvil
  delay(3000);

  Serial.println("\n>>> COMANDOS DISPONIBLES EN MONITOR SERIE:");
  Serial.println(" - Escribe 'parar' para pausar los envíos.");
  Serial.println(" - Escribe 'continuar' para reanudarlos.");
  Serial.println(" - Escribe un número (ej. 10) para cambiar el intervalo en segundos.\n");
}

void loop() {
  // --- Gestión de Comandos por Monitor Serie ---
  if (Serial.available() > 0) {
    String comando = Serial.readStringUntil('\n');
    comando.trim(); 

    if (comando.equalsIgnoreCase("parar")) {
      envioActivo = false;
      Serial.println("\n[ESTADO]: Envío PAUSADO por el usuario.");
    } 
    else if (comando.equalsIgnoreCase("continuar") || comando.equalsIgnoreCase("seguir")) {
      envioActivo = true;
      Serial.println("\n[ESTADO]: Envío REANUDADO.");
    }
    else {
      // Si introduce un número, lo interpretamos como nuevos segundos para el intervalo
      int nuevoIntervaloSeg = comando.toInt();
      if (nuevoIntervaloSeg > 0) {
        intervalo = (unsigned long)nuevoIntervaloSeg * 1000;
        Serial.printf("\n[CONFIG]: Intervalo actualizado a %d segundos.\n", nuevoIntervaloSeg);
      } else {
        Serial.println("\n[AVISO]: Comando no reconocido.");
      }
    }
  }

  // --- Temporizador dinámico ---
  unsigned long tiempoActual = millis();
  if (tiempoActual - tiempoAnterior >= intervalo) {
    tiempoAnterior = tiempoActual;

    if (envioActivo) {
      if (WiFi.status() == WL_CONNECTED) {
        Serial.println("\n[SISTEMA]: Generando telemetría y enviando a Firebase...");

        // 1. Simulación matemática de movimiento circular en Ciudad Real
        double latitudActual = CENTRO_LAT + (RADIO_GIRO * sin(angulo));
        double longitudActual = CENTRO_LON + (RADIO_GIRO * cos(angulo));
        
        angulo += 0.2; 
        if (angulo >= (2 * M_PI)) angulo = 0.0; 

        // 2. Simulación de Telemetría Aleatoria
        float velocidad = random(20, 46);          // Entre 20 y 45 km/h
        float voltaje = random(360, 421) / 10.0;   // Entre 36.0V y 42.0V

        // 3. Estructuración del JSON
        JsonDocument doc;
        doc["latitud"] = latitudActual;
        doc["longitud"] = longitudActual;
        doc["velocidad_kmh"] = velocidad;
        doc["voltaje_v"] = voltaje;
        doc["timestamp"] = millis(); 

        String jsonString;
        serializeJson(doc, jsonString);

        // 4. Envío por HTTPS (POST)
        WiFiClientSecure client;
        client.setInsecure(); 
        
        HTTPClient http;
        http.setTimeout(10000);
        int codigoRespuesta = 0;

        if (http.begin(client, URL_ENDPOINT)) {
          http.addHeader("Content-Type", "application/json");
          http.addHeader("Connection", "close");
          
          codigoRespuesta = http.POST(jsonString);
          String respuestaServidor = http.getString();
          
          http.end();
          client.stop();

          // 5. Resultados en el Monitor
          Serial.print(" -> Código HTTP Firebase: "); 
          Serial.println(codigoRespuesta);
          if (codigoRespuesta == 200 || codigoRespuesta == 201) {
            Serial.print(" -> Datos enviados: "); 
            serializeJson(doc, Serial); 
            Serial.println();
          } else {
            Serial.printf(" -> Error de envío (Código: %d)\n", codigoRespuesta);
          }
        } else {
          Serial.println("[ERROR]: No se pudo iniciar HTTPClient.");
        }
        Serial.println("----------------------------------------");

      } else {
        Serial.println("[ERROR]: WiFi desconectado.");
      }
    } else {
      Serial.println("[AVISO]: Envío omitido (En pausa).");
    }
  }
}