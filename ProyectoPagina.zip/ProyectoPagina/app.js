// ==========================================
// 1. CONFIGURACIÓN DE FIREBASE
// ==========================================
const firebaseConfig = {
  apiKey: "TU_API_KEY",
  authDomain: "tu-proyecto.firebaseapp.com",
  databaseURL: "https://tu-proyecto-default-rtdb.firebaseio.com",
  projectId: "tu-proyecto",
  storageBucket: "tu-proyecto.appspot.com",
  messagingSenderId: "1234567890",
  appId: "1:1234567890:web:abcdef"
};

// Inicialización condicional de Firebase
let database = null;
if (typeof firebase !== 'undefined' && firebaseConfig.apiKey !== "TU_API_KEY") {
  firebase.initializeApp(firebaseConfig);
  database = firebase.database();
}

// ==========================================
// 2. CONFIGURACIÓN DEL MAPA (Leaflet.js + OpenStreetMap Público)
// ==========================================
// Coordenadas iniciales simuladas
let currentLat = 40.416775;
let currentLng = -3.703790;

const map = L.map('map').setView([currentLat, currentLng], 17);

// SOLUCIÓN 1: Capa gratuita de OpenStreetMap (Sin API Key)
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

// Marcador del coche y línea del trazado recorrido
const carMarker = L.marker([currentLat, currentLng]).addTo(map);
carMarker.bindPopup("<b>Monoplaza Eléctrico</b><br>Iniciando posición...").openPopup();

const trackPolyline = L.polyline([], { color: '#0284c7', weight: 5 }).addTo(map);

// Función para actualizar la ubicación GPS en el mapa
function updateGPSLocation(lat, lng, speed = 0) {
  const newLatLng = new L.LatLng(lat, lng);

  carMarker.setLatLng(newLatLng);
  map.panTo(newLatLng); // Centra el mapa suavemente en el coche
  trackPolyline.addLatLng(newLatLng); // Dibuja la línea de la ruta

  carMarker.getPopup().setContent(
    `<b>Monoplaza Eléctrico</b><br>Velocidad: ${speed} km/h<br>Lat: ${lat.toFixed(5)}, Lng: ${lng.toFixed(5)}`
  );
}

// ==========================================
// 3. CONFIGURACIÓN DE GRÁFICAS (Chart.js)
// ==========================================
const ctxSpeed = document.getElementById('speedChart').getContext('2d');
const speedChart = new Chart(ctxSpeed, {
  type: 'line',
  data: {
    labels: [],
    datasets: [{
      label: 'Velocidad (km/h)',
      borderColor: '#38bdf8',
      backgroundColor: 'rgba(56, 189, 248, 0.1)',
      data: [],
      fill: true,
      tension: 0.3
    }]
  },
  options: {
    responsive: true,
    scales: {
      x: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } },
      y: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } }
    },
    plugins: { legend: { labels: { color: '#f8fafc' } } }
  }
});

const ctxPower = document.getElementById('powerChart').getContext('2d');
const powerChart = new Chart(ctxPower, {
  type: 'line',
  data: {
    labels: [],
    datasets: [{
      label: 'Potencia (kW)',
      borderColor: '#f59e0b',
      backgroundColor: 'rgba(245, 158, 11, 0.1)',
      data: [],
      fill: true,
      tension: 0.3
    }]
  },
  options: {
    responsive: true,
    scales: {
      x: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } },
      y: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } }
    },
    plugins: { legend: { labels: { color: '#f8fafc' } } }
  }
});

function updateChart(chart, label, value) {
  chart.data.labels.push(label);
  chart.data.datasets[0].data.push(value);

  if (chart.data.labels.length > 10) {
    chart.data.labels.shift();
    chart.data.datasets[0].data.shift();
  }
  chart.update();
}

// ==========================================
// 4. LÓGICA DE DATOS: FIREBASE O SIMULADOR
// ==========================================

const statusBadge = document.getElementById('connection-status');
const statusText = document.getElementById('status-text');

if (database) {
  // LECTURA REAL DESDE FIREBASE
  const telemetryRef = database.ref('telemetry/latest');

  telemetryRef.on('value', (snapshot) => {
    const data = snapshot.val();
    if (data) {
      const timeLabel = new Date().toLocaleTimeString();

      const speed = data.speed ?? 0;
      const soc = data.battery?.soc ?? 0;
      const rpm = data.rpm ?? 0;
      const temp = data.battery?.temp ?? 0;
      const power = data.power ?? ((data.battery?.voltage * data.battery?.current) / 1000).toFixed(1);

      document.getElementById('val-speed').innerText = speed;
      document.getElementById('val-battery').innerText = soc;
      document.getElementById('val-rpm').innerText = rpm;
      document.getElementById('val-temp-bat').innerText = temp;
      document.getElementById('val-power').innerText = power;

      updateChart(speedChart, timeLabel, speed);
      updateChart(powerChart, timeLabel, power);

      if (data.gps && data.gps.lat && data.gps.lng) {
        updateGPSLocation(data.gps.lat, data.gps.lng, speed);
      }

      statusBadge.className = "status-badge status-online";
      statusText.innerText = "En vivo (Firebase)";
    }
  });

} else {
  // SIMULADOR TEMPORAL (SPRINT 0 / PRUEBAS LOCALES)
  console.warn("API Key de Firebase no detectada. Activando modo simulación.");
  
  statusBadge.className = "status-badge status-online";
  statusText.innerText = "Modo Simulación";

  // Ángulo para simular un recorrido circular/curvado del monoplaza
  let angle = 0;

  setInterval(() => {
    const timeLabel = new Date().toLocaleTimeString();

    // 1. Simulación de valores de telemetría
    const simSpeed = Math.floor(Math.random() * 25) + 55; // 55 - 80 km/h
    const simSoc = (95 - (Date.now() / 200000) % 20).toFixed(1);
    const simRpm = simSpeed * 45;
    const simTemp = (32 + Math.random() * 4).toFixed(1);
    const simPower = (simSpeed * 0.18).toFixed(1);

    // 2. Simulación de trayectoria GPS dibujando un circuito curvilíneo
    angle += 0.1;
    currentLat += Math.sin(angle) * 0.00015;
    currentLng += Math.cos(angle) * 0.0002;

    // 3. Actualización de la interfaz
    document.getElementById('val-speed').innerText = simSpeed;
    document.getElementById('val-battery').innerText = simSoc;
    document.getElementById('val-rpm').innerText = simRpm;
    document.getElementById('val-temp-bat').innerText = simTemp;
    document.getElementById('val-power').innerText = simPower;

    updateChart(speedChart, timeLabel, simSpeed);
    updateChart(powerChart, timeLabel, simPower);

    // Actualización de ubicación en el mapa sin marcas de agua
    updateGPSLocation(currentLat, currentLng, simSpeed);

  }, 2000);
}