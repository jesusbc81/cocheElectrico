// Endpoint de Firebase (Mismo endpoint REST que el ESP8266)
const ENDPOINT_URL = "https://jbc-app-daw-default-rtdb.europe-west1.firebasedatabase.app/datos.json";

// Variables globales de estado
let refreshIntervalSeconds = 40; // Por defecto 40 segundos
let countdownValue = refreshIntervalSeconds;
let fetchTimer = null;
let countdownTimer = null;

// Instancia del mapa de Leaflet
let map = null;
let marker = null;

// Inicialización de la aplicación
document.addEventListener("DOMContentLoaded", () => {
  initMap();
  setupEventListeners();
  
  // Primera lectura inmediata
  fetchTelemetryData();
  
  // Iniciar temporizadores
  startTimers();
});

// 1. Inicializar Mapa gratuito OpenStreetMap
function initMap() {
  // Centro inicial por defecto en Ciudad Real
  const defaultLat = 38.98626;
  const defaultLon = -3.92742;

  map = L.map('map').setView([defaultLat, defaultLon], 14);

  // Capa gráfica de OpenStreetMap (Gratuita y libre)
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '© OpenStreetMap'
  }).addTo(map);

  // Marcador en el mapa
  marker = L.marker([defaultLat, defaultLon]).addTo(map)
    .bindPopup('Esperando datos del ESP8266...')
    .openPopup();
}

// 2. Configurar eventos de la interfaz
function setupEventListeners() {
  const btnUpdate = document.getElementById("btnUpdateRefresh");
  const inputRefresh = document.getElementById("refreshInput");

  btnUpdate.addEventListener("click", () => {
    const newVal = parseInt(inputRefresh.value, 10);
    if (newVal && newVal > 0) {
      refreshIntervalSeconds = newVal;
      countdownValue = refreshIntervalSeconds;
      document.getElementById("countdownTimer").textContent = countdownValue;
      
      // Reiniciar temporizadores con la nueva frecuencia
      startTimers();
    }
  });
}

// 3. Obtener los datos desde Firebase usando 'fetch'
async function fetchTelemetryData() {
  const statusBadge = document.getElementById("statusBadge");
  statusBadge.textContent = "Actualizando...";
  statusBadge.style.backgroundColor = "#eab308";

  try {
    // Petición GET a Firebase devolviendo los últimos registros creados por POST
    const response = await fetch(`${ENDPOINT_URL}?orderBy="$key"&limitToLast=1`);
    if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);

    const data = await response.json();

    if (data) {
      // Firebase devuelve un objeto cuyas llaves son IDs únicos generated por POST
      const keys = Object.keys(data);
      const lastKey = keys[keys.length - 1];
      const telemetry = data[lastKey];

      // Actualizar la interfaz gráfica con el último registro recuperado
      updateDashboardUI(telemetry);

      statusBadge.textContent = "Online";
      statusBadge.style.backgroundColor = "#22c55e";
    } else {
      statusBadge.textContent = "Sin datos";
      statusBadge.style.backgroundColor = "#64748b";
    }

  } catch (error) {
    console.error("Error al consultar Firebase:", error);
    statusBadge.textContent = "Error de conexión";
    statusBadge.style.backgroundColor = "#ef4444";
  }
}

// 4. Actualizar componentes gráficos
function updateDashboardUI(data) {
  // --- A. Velocidad (Dial Redondo) ---
  const speed = data.velocidad_kmh || 0;
  document.getElementById("speedValue").textContent = speed.toFixed(1);
  
  // Mapear velocidad (0 a 100 km/h) a la longitud del arco SVG (188 a 0)
  const maxSpeed = 100;
  const clampedSpeed = Math.min(Math.max(speed, 0), maxSpeed);
  const dashOffset = 188 - (clampedSpeed / maxSpeed) * 188;
  document.getElementById("speedDialFill").style.strokeDashoffset = dashOffset;

  // --- B. Voltaje (Meter de Batería) ---
  const voltage = data.voltaje_v || 0;
  document.getElementById("voltageValue").textContent = `${voltage.toFixed(1)} V`;
  
  // Mapear voltaje entre un rango de 30V y 45V para el porcentaje de la barra
  const minV = 30;
  const maxV = 45;
  const percentage = Math.min(Math.max(((voltage - minV) / (maxV - minV)) * 100, 0), 100);
  document.getElementById("voltageMeterFill").style.width = `${percentage}%`;

  // --- C. Posición GPS (Mapa OpenStreetMap) ---
  if (data.latitud && data.longitud) {
    const lat = data.latitud;
    const lon = data.longitud;

    document.getElementById("latValue").textContent = lat.toFixed(5);
    document.getElementById("lonValue").textContent = lon.toFixed(5);

    // Mover la vista del mapa y ajustar la posición del marcador
    const newPos = [lat, lon];
    map.panTo(newPos);
    marker.setLatLng(newPos);
    marker.setPopupContent(`<b>ESP8266</b><br>Velocidad: ${speed} km/h<br>Voltaje: ${voltage} V`).openPopup();
  }

  // --- D. Timestamp ---
  if (data.timestamp) {
    const date = new Date();
    document.getElementById("timestampValue").textContent = date.toLocaleTimeString();
  }
}

// 5. Control del temporizador de actualización
function startTimers() {
  if (fetchTimer) clearInterval(fetchTimer);
  if (countdownTimer) clearInterval(countdownTimer);

  countdownValue = refreshIntervalSeconds;
  document.getElementById("countdownTimer").textContent = countdownValue;

  // Cuenta regresiva visual cada segundo
  countdownTimer = setInterval(() => {
    countdownValue--;
    if (countdownValue < 0) countdownValue = refreshIntervalSeconds;
    document.getElementById("countdownTimer").textContent = countdownValue;
  }, 1000);

  // Ejecución de la llamada HTTP en el intervalo indicado
  fetchTimer = setInterval(() => {
    fetchTelemetryData();
  }, refreshIntervalSeconds * 1000);
}