// --- CONFIGURATION & ENDPOINTS ---
const ENDPOINT_URL =
  "https://jbc-app-daw-default-rtdb.europe-west1.firebasedatabase.app/datos.json";
const DEFAULT_CITY_LAT = 38.98626;
const DEFAULT_CITY_LON = -3.92742;

// --- APPLICATION STATE ---
let refreshIntervalSeconds = 40;
let countdownValue = refreshIntervalSeconds;
let fetchTimer = null;
let countdownTimer = null;

// GPS & Trajectory History State
let telemetryHistory = []; // Array of {lat, lon, speed, voltage, timestamp, key}
let totalHaversineDistanceKm = 0.0;

// Map & Polyline Instances
let map = null;
let mapMarker = null;
let mapPolyline = null;

// Canvas Context for Trajectory Chart
let trajCanvas = null;
let trajCtx = null;

// --- DOM ELEMENT REFERENCES ---
const statusBadge = document.getElementById("statusBadge");
const refreshInput = document.getElementById("refreshInput");
const btnApplyRefresh = document.getElementById("btnApplyRefresh");
const btnManualRefresh = document.getElementById("btnManualRefresh");
const countdownTimerEl = document.getElementById("countdownTimer");

// Gauges DOM
const speedValueEl = document.getElementById("speedValue");
const speedDialFill = document.getElementById("speedDialFill");
const speedAlertEl = document.getElementById("speedAlert");

const voltageValueEl = document.getElementById("voltageValue");
const voltageMeterFill = document.getElementById("voltageMeterFill");
const voltageStatusText = document.getElementById("voltageStatusText");

// Metrics & Trajectory DOM
const totalPointsSummary = document.getElementById("totalPointsSummary");
const timestampValueEl = document.getElementById("timestampValue");
const latValueEl = document.getElementById("latValue");
const lonValueEl = document.getElementById("lonValue");

const totalDistanceValueEl = document.getElementById("totalDistanceValue");
const distanceUnitEl = document.getElementById("distanceUnit");
const recordedPointsCountEl = document.getElementById("recordedPointsCount");
const trajectorySpanValueEl = document.getElementById("trajectorySpanValue");
const btnRecenterMap = document.getElementById("btnRecenterMap");
const btnClearHistory = document.getElementById("btnClearHistory");

// --- INITIALIZATION ---
document.addEventListener("DOMContentLoaded", () => {
  initLeafletMap();
  initTrajectoryCanvas();
  setupEventListeners();

  // Fetch telemetry data immediately on boot
  fetchTelemetryData();

  // Start countdown and fetch interval
  startTimers();

  // Window resize handler to maintain vector aspect ratio
  window.addEventListener("resize", () => {
    resizeTrajectoryCanvas();
    drawScaledTrajectoryCanvas();
  });
});

// 1. INITIALIZE LEAFLET MAP
function initLeafletMap() {
  map = L.map("map", {
    zoomControl: true,
    attributionControl: false,
  }).setView([DEFAULT_CITY_LAT, DEFAULT_CITY_LON], 15);

  // Free OpenStreetMap tile server
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
  }).addTo(map);

  // Custom marker icon or fallback
  const neonIcon = L.divIcon({
    className: "custom-leaflet-marker",
    html: `<div style="width: 18px; height: 18px; background: #ff0055; border: 3px solid #ffffff; border-radius: 50%; box-shadow: 0 0 15px #ff0055, 0 0 25px #00f3ff;"></div>`,
    iconSize: [18, 18],
    iconAnchor: [9, 9],
  });

  mapMarker = L.marker([DEFAULT_CITY_LAT, DEFAULT_CITY_LON], { icon: neonIcon })
    .addTo(map)
    .bindPopup(
      '<b style="color:#00f3ff">ESP8266 Telemetría</b><br>Iniciando recepción de datos...',
    );

  // Polyline for map track
  mapPolyline = L.polyline([], {
    color: "#00f3ff",
    weight: 4,
    opacity: 0.8,
    smoothFactor: 1,
  }).addTo(map);
}

// 2. INITIALIZE VECTOR TRAJECTORY CANVAS
function initTrajectoryCanvas() {
  trajCanvas = document.getElementById("trajectoryCanvas");
  trajCtx = trajCanvas.getContext("2d");
  resizeTrajectoryCanvas();
}

function resizeTrajectoryCanvas() {
  if (!trajCanvas) return;
  const rect = trajCanvas.getBoundingClientRect();
  trajCanvas.width = rect.width * (window.devicePixelRatio || 1);
  trajCanvas.height = rect.height * (window.devicePixelRatio || 1);
}

// 3. SETUP USER EVENT LISTENERS
function setupEventListeners() {
  btnApplyRefresh.addEventListener("click", () => {
    const val = parseInt(refreshInput.value, 10);
    if (val && val >= 2 && val <= 300) {
      refreshIntervalSeconds = val;
      startTimers();
      showNotification(`Frecuencia ajustada a ${val} segundos`);
    } else {
      alert(
        "Por favor introduce un intervalo de refresco válido (2 - 300 segundos).",
      );
    }
  });

  btnManualRefresh.addEventListener("click", () => {
    fetchTelemetryData();
    countdownValue = refreshIntervalSeconds;
    countdownTimerEl.textContent = countdownValue;
  });

  btnRecenterMap.addEventListener("click", () => {
    if (telemetryHistory.length > 0) {
      const last = telemetryHistory[telemetryHistory.length - 1];
      map.setView([last.lat, last.lon], 16, { animate: true });
    } else {
      map.setView([DEFAULT_CITY_LAT, DEFAULT_CITY_LON], 15);
    }
  });

  btnClearHistory.addEventListener("click", () => {
    telemetryHistory = [];
    totalHaversineDistanceKm = 0;
    mapPolyline.setLatLngs([]);
    updateTrajectoryMetrics();
    drawScaledTrajectoryCanvas();
    showNotification("Historial de trayectoria reiniciado");
  });
}

// 4. FETCH TELEMETRY DATA FROM FIREBASE REST
async function fetchTelemetryData() {
  updateStatusBadge("loading", "CONSULTANDO...");

  try {
    // Fetch historical batch or last N items to build complete smooth path
    const response = await fetch(
      `${ENDPOINT_URL}?orderBy="$key"&limitToLast=100`,
    );
    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const data = await response.json();

    if (data && typeof data === "object") {
      processIncomingFirebaseData(data);
      updateStatusBadge("online", "ONLINE");
    } else {
      updateStatusBadge("warning", "SIN DATOS");
    }
  } catch (error) {
    console.error("Error al obtener datos de Firebase:", error);
    updateStatusBadge("error", "ERROR DE RED");
  }
}

// 5. PROCESS FIREBASE DATA & RECONSTRUCT PATH
function processIncomingFirebaseData(dataObject) {
  const keys = Object.keys(dataObject);
  if (keys.length === 0) return;

  // Sort by key or timestamp
  keys.sort();

  const newHistory = [];
  let calculatedDistanceKm = 0.0;

  for (let i = 0; i < keys.length; i++) {
    const key = keys[i];
    const item = dataObject[key];

    if (
      item &&
      typeof item.latitud === "number" &&
      typeof item.longitud === "number"
    ) {
      const point = {
        lat: item.latitud,
        lon: item.longitud,
        speed: parseFloat(item.velocidad_kmh || 0),
        voltage: parseFloat(item.voltaje_v || 0),
        timestamp: item.timestamp || Date.now(),
        key: key,
      };

      // Calculate incremental Haversine distance between consecutive points
      if (newHistory.length > 0) {
        const prev = newHistory[newHistory.length - 1];
        const distSeg = calculateHaversineDistance(
          prev.lat,
          prev.lon,
          point.lat,
          point.lon,
        );
        calculatedDistanceKm += distSeg;
      }

      newHistory.push(point);
    }
  }

  telemetryHistory = newHistory;
  totalHaversineDistanceKm = calculatedDistanceKm;

  if (telemetryHistory.length > 0) {
    const latestPoint = telemetryHistory[telemetryHistory.length - 1];

    // Update Gauges and Display Labels
    updateGaugesUI(latestPoint);

    // Update Map Marker & Polyline
    const latLngs = telemetryHistory.map((pt) => [pt.lat, pt.lon]);
    mapPolyline.setLatLngs(latLngs);
    mapMarker.setLatLng([latestPoint.lat, latestPoint.lon]);
    mapMarker.setPopupContent(`
          <div class="font-orbitron text-xs">
            <b style="color:#00f3ff">ESP8266 Telemetría</b><br>
            Velocidad: <span style="color:#00ff66">${latestPoint.speed.toFixed(1)} km/h</span><br>
            Voltaje: <span style="color:#ffaa00">${latestPoint.voltage.toFixed(1)} V</span>
          </div>
        `);

    // Update Trajectory Box Metrics & Vector Canvas Rendering
    updateTrajectoryMetrics();
    drawScaledTrajectoryCanvas();
  }
}

// 6. UPDATE GAUGES AND METRICS UI
function updateGaugesUI(point) {
  // --- SPEED DIAL ---
  const speed = point.speed;
  speedValueEl.textContent = speed.toFixed(1);

  // Gauge SVG offset math: stroke-dasharray = 251.2
  // 0 km/h -> dashoffset = 251.2 (empty)
  // 100 km/h -> dashoffset = 0 (full)
  const maxSpeed = 100;
  const clampedSpeed = Math.min(Math.max(speed, 0), maxSpeed);
  const strokeOffset = 251.2 - (clampedSpeed / maxSpeed) * 251.2;
  speedDialFill.style.strokeDashoffset = strokeOffset;

  if (speed > 80) {
    speedDialFill.style.stroke = "var(--neon-magenta)";
    speedAlertEl.textContent = "ALERTA: VELOCIDAD ELEVADA";
    speedAlertEl.className =
      "text-[10px] text-rose-400 font-bold mt-1 tracking-wider";
  } else {
    speedDialFill.style.stroke = "var(--neon-cyan)";
    speedAlertEl.textContent = "ESTADO: OPTIMO";
    speedAlertEl.className = "text-[10px] text-cyan-400 font-medium mt-1";
  }

  // --- VOLTAGE METER ---
  const voltage = point.voltage;
  voltageValueEl.textContent = voltage.toFixed(1);

  // Voltage range: 30V to 45V (15V delta)
  const minV = 30.0;
  const maxV = 45.0;
  const vPercentage = Math.min(
    Math.max(((voltage - minV) / (maxV - minV)) * 100, 0),
    100,
  );

  voltageMeterFill.style.width = `${vPercentage}%`;

  if (voltage < 34.0) {
    voltageMeterFill.className =
      "meter-fill-bar h-full rounded-lg bg-rose-500 text-rose-400";
    voltageStatusText.textContent = "Batería Baja (Requiere recarga)";
    voltageStatusText.className =
      "text-xs text-center font-semibold text-rose-400 border-t border-slate-800/80 pt-2";
  } else if (voltage < 38.0) {
    voltageMeterFill.className =
      "meter-fill-bar h-full rounded-lg bg-amber-500 text-amber-400";
    voltageStatusText.textContent = "Carga Media / Descargando";
    voltageStatusText.className =
      "text-xs text-center font-semibold text-amber-400 border-t border-slate-800/80 pt-2";
  } else {
    voltageMeterFill.className =
      "meter-fill-bar h-full rounded-lg bg-emerald-500 text-emerald-400";
    voltageStatusText.textContent = "Nivel de Voltaje Óptimo";
    voltageStatusText.className =
      "text-xs text-center font-semibold text-emerald-400 border-t border-slate-800/80 pt-2";
  }

  // --- CARD DETAILS ---
  latValueEl.textContent = point.lat.toFixed(5);
  lonValueEl.textContent = point.lon.toFixed(5);

  const d = new Date(point.timestamp || Date.now());
  timestampValueEl.textContent = d.toLocaleTimeString();
}

// 7. TRAJECTORY METRICS & COMPUTATIONS
function updateTrajectoryMetrics() {
  const count = telemetryHistory.length;
  recordedPointsCountEl.textContent = count;
  totalPointsSummary.textContent = count;

  // Format distance nicely in meters or km
  if (totalHaversineDistanceKm < 1.0) {
    const meters = totalHaversineDistanceKm * 1000;
    totalDistanceValueEl.textContent = meters.toFixed(0);
    distanceUnitEl.textContent = "m";
  } else {
    totalDistanceValueEl.textContent = totalHaversineDistanceKm.toFixed(2);
    distanceUnitEl.textContent = "km";
  }

  // Compute bounding box span area approx
  if (count > 1) {
    let minLat = Infinity,
      maxLat = -Infinity;
    let minLon = Infinity,
      maxLon = -Infinity;

    telemetryHistory.forEach((pt) => {
      if (pt.lat < minLat) minLat = pt.lat;
      if (pt.lat > maxLat) maxLat = pt.lat;
      if (pt.lon < minLon) minLon = pt.lon;
      if (pt.lon > maxLon) maxLon = pt.lon;
    });

    const latDistMeters =
      calculateHaversineDistance(minLat, minLon, maxLat, minLon) * 1000;
    const lonDistMeters =
      calculateHaversineDistance(minLat, minLon, minLat, maxLon) * 1000;
    const areaSqMeters = latDistMeters * lonDistMeters;

    if (areaSqMeters > 1000000) {
      trajectorySpanValueEl.textContent =
        (areaSqMeters / 1000000).toFixed(2) + " km²";
    } else {
      trajectorySpanValueEl.textContent = areaSqMeters.toFixed(0);
    }
  } else {
    trajectorySpanValueEl.textContent = "0";
  }
}

// 8. DRAW VECTOR TRAJECTORY TO SCALED CANVAS (NEON GLOW)
function drawScaledTrajectoryCanvas() {
  if (!trajCtx || !trajCanvas) return;

  const w = trajCanvas.width;
  const h = trajCanvas.height;

  // Clear Canvas
  trajCtx.clearRect(0, 0, w, h);

  if (telemetryHistory.length < 1) {
    // Draw empty indicator message
    trajCtx.fillStyle = "rgba(148, 163, 184, 0.4)";
    trajCtx.font = "bold 14px Orbitron, sans-serif";
    trajCtx.textAlign = "center";
    trajCtx.fillText(
      "ESPERANDO PUNTOS GPS PARA DIBUJAR LA TRAYECTORIA...",
      w / 2,
      h / 2,
    );
    return;
  }

  // 1. Calculate Latitude and Longitude Bounds (Min/Max)
  let minLat = Infinity,
    maxLat = -Infinity;
  let minLon = Infinity,
    maxLon = -Infinity;

  telemetryHistory.forEach((p) => {
    if (p.lat < minLat) minLat = p.lat;
    if (p.lat > maxLat) maxLat = p.lat;
    if (p.lon < minLon) minLon = p.lon;
    if (p.lon > maxLon) maxLon = p.lon;
  });

  // Add safety padding factor if all points are identical or closely clustered
  let latSpan = maxLat - minLat;
  let lonSpan = maxLon - minLon;

  if (latSpan < 0.0001) {
    minLat -= 0.0005;
    maxLat += 0.0005;
    latSpan = 0.001;
  }
  if (lonSpan < 0.0001) {
    minLon -= 0.0005;
    maxLon += 0.0005;
    lonSpan = 0.001;
  }

  const padding = 50 * (window.devicePixelRatio || 1);
  const drawWidth = w - padding * 2;
  const drawHeight = h - padding * 2;

  // Helper function to map GPS (lat, lon) to Canvas (x, y) coordinates
  // Note: Longitude maps to X (Left -> Right), Latitude maps to Y (Bottom -> Top, inverted on canvas)
  const mapToCanvas = (lat, lon) => {
    const x = padding + ((lon - minLon) / lonSpan) * drawWidth;
    const y = h - (padding + ((lat - minLat) / latSpan) * drawHeight);
    return { x, y };
  };

  // 2. Draw Vector Path Line with Multi-layered Glowing Effect
  if (telemetryHistory.length > 1) {
    // Outer Neon Glow Pass
    trajCtx.beginPath();
    telemetryHistory.forEach((pt, idx) => {
      const coords = mapToCanvas(pt.lat, pt.lon);
      if (idx === 0) trajCtx.moveTo(coords.x, coords.y);
      else trajCtx.lineTo(coords.x, coords.y);
    });

    trajCtx.strokeStyle = "rgba(255, 0, 85, 0.4)";
    trajCtx.lineWidth = 8 * (window.devicePixelRatio || 1);
    trajCtx.lineCap = "round";
    trajCtx.lineJoin = "round";
    trajCtx.shadowColor = "#ff0055";
    trajCtx.shadowBlur = 15;
    trajCtx.stroke();

    // Inner Sharp Cyan/Magenta Core Pass
    trajCtx.beginPath();
    telemetryHistory.forEach((pt, idx) => {
      const coords = mapToCanvas(pt.lat, pt.lon);
      if (idx === 0) trajCtx.moveTo(coords.x, coords.y);
      else trajCtx.lineTo(coords.x, coords.y);
    });

    const gradient = trajCtx.createLinearGradient(0, 0, w, h);
    gradient.addColorStop(0, "#00f3ff");
    gradient.addColorStop(0.5, "#00ff66");
    gradient.addColorStop(1, "#ff0055");

    trajCtx.strokeStyle = gradient;
    trajCtx.lineWidth = 3 * (window.devicePixelRatio || 1);
    trajCtx.shadowBlur = 0;
    trajCtx.stroke();
  }

  // 3. Draw Nodes / Waypoints
  telemetryHistory.forEach((pt, idx) => {
    const coords = mapToCanvas(pt.lat, pt.lon);

    if (idx === 0) {
      // START POINT MARKER (GREEN)
      trajCtx.beginPath();
      trajCtx.arc(
        coords.x,
        coords.y,
        7 * (window.devicePixelRatio || 1),
        0,
        Math.PI * 2,
      );
      trajCtx.fillStyle = "#00ff66";
      trajCtx.shadowColor = "#00ff66";
      trajCtx.shadowBlur = 10;
      trajCtx.fill();

      trajCtx.fillStyle = "#ffffff";
      trajCtx.font = "bold 10px Rajdhani, sans-serif";
      trajCtx.fillText(" INICIO", coords.x + 10, coords.y + 4);
    } else if (idx === telemetryHistory.length - 1) {
      // LATEST POINT MARKER (PINK / CYAN ANIMATED GLOW)
      trajCtx.beginPath();
      trajCtx.arc(
        coords.x,
        coords.y,
        9 * (window.devicePixelRatio || 1),
        0,
        Math.PI * 2,
      );
      trajCtx.fillStyle = "#ff0055";
      trajCtx.shadowColor = "#ff0055";
      trajCtx.shadowBlur = 15;
      trajCtx.fill();

      // Outer ring
      trajCtx.beginPath();
      trajCtx.arc(
        coords.x,
        coords.y,
        14 * (window.devicePixelRatio || 1),
        0,
        Math.PI * 2,
      );
      trajCtx.strokeStyle = "rgba(0, 243, 255, 0.8)";
      trajCtx.lineWidth = 2;
      trajCtx.stroke();
    } else {
      // Intermediate small waypoints
      trajCtx.beginPath();
      trajCtx.arc(
        coords.x,
        coords.y,
        2.5 * (window.devicePixelRatio || 1),
        0,
        Math.PI * 2,
      );
      trajCtx.fillStyle = "rgba(0, 243, 255, 0.6)";
      trajCtx.shadowBlur = 0;
      trajCtx.fill();
    }
  });
}

// 9. HAVERSINE FORMULA FOR DISTANCE CALCULATION
// Calculates great-circle distance between two GPS points in kilometers
function calculateHaversineDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // Earth's mean radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c; // Distance in kilometers
}

// 10. TIMERS & STATUS MANAGEMENT
function startTimers() {
  if (fetchTimer) clearInterval(fetchTimer);
  if (countdownTimer) clearInterval(countdownTimer);

  countdownValue = refreshIntervalSeconds;
  countdownTimerEl.textContent = countdownValue;

  // 1-Second tick countdown
  countdownTimer = setInterval(() => {
    countdownValue--;
    if (countdownValue < 0) {
      countdownValue = refreshIntervalSeconds;
    }
    countdownTimerEl.textContent = countdownValue;
  }, 1000);

  // REST Polling Interval
  fetchTimer = setInterval(() => {
    fetchTelemetryData();
  }, refreshIntervalSeconds * 1000);
}

function updateStatusBadge(type, text) {
  statusBadge.innerHTML = `<span class="w-2 h-2 rounded-full ${getStatusDotClass(type)}"></span><span>${text}</span>`;
  statusBadge.className = `status-pulse px-4 py-1.5 rounded-full text-xs font-orbitron font-bold tracking-wider flex items-center gap-2 ${getStatusBadgeClass(type)}`;
}

function getStatusDotClass(type) {
  if (type === "online") return "bg-emerald-400";
  if (type === "loading") return "bg-cyan-400 animate-spin";
  if (type === "warning") return "bg-amber-400";
  return "bg-rose-400";
}

function getStatusBadgeClass(type) {
  if (type === "online")
    return "bg-emerald-500/10 border border-emerald-500/40 text-emerald-400";
  if (type === "loading")
    return "bg-cyan-500/10 border border-cyan-500/40 text-cyan-400";
  if (type === "warning")
    return "bg-amber-500/10 border border-amber-500/40 text-amber-400";
  return "bg-rose-500/10 border border-rose-500/40 text-rose-400";
}

function showNotification(msg) {
  console.log("[DASHBOARD]: " + msg);
}
